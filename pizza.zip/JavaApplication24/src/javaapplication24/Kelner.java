/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication24;

/**
 *
 * @author student
 */
class Kelner {
    private PizzaBuilder builder;
    public void setBuilder(PizzaBuilder builder) {
        this.builder = builder;
    }
    public Pizza getZestaw() {
        return builder.getZestaw();
    }
    public void zamow() {
        builder.newZestaw();
        builder.rodzajCiasta();
        builder.rodzajSosu();
        builder.zestawSkladnikow();
    }

    public Pizza pobierz(){
        return builder.getZestaw();
    }

}
